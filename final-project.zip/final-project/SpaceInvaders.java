class SpaceInvaders {
    public static void main(String[] args) {

        // Creates game background
        StdDraw.setXscale(-500.0, 500.0);
        StdDraw.setYscale(-500.0, 500.0);
        StdDraw.picture(0, 0, "background.jpg");


        //  StdDraw.setPenColor(StdDraw.WHITE);
        // StdDraw.filledCircle(25.0, 25.0, 5.0);
        //   StdDraw.picture(0, -400.0, "ptonship.png");

        Player pton = new Player(3, 0.0, -400.0, "ptonship.png");

        while (true) {
            if (StdDraw.isKeyPressed(65)) {

            }
        }
        //    }
