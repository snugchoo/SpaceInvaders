class Player {
    private int score;
    private int lives;
    private double posX;
    private double posY;
    private String name;
    //   private int enemyLives;

    public Player(int lives, double posX, double posY, String name) {
        this.lives = lives;
        this.posX = posX;
        this.posY = posY;
        this.name = name;
        StdDraw.picture(this.posX, this.posY, this.name);
    }

    public void move() {
        posX--;
    }

    public static void main(String[] args) {

    }
}
